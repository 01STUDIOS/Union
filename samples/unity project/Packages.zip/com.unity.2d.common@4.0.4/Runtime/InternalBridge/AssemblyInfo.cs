using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.2D.AnimationZeroOne.Runtime")]
[assembly: InternalsVisibleTo("Unity.2D.Animation.Editor")]
[assembly: InternalsVisibleTo("Unity.2D.IK.Editor")]
